packrat::snapshot()
packrat::bundle(file = paste0("../oec-bundles/oec-packages-snapshot-", Sys.Date(), ".tar.gz"))
