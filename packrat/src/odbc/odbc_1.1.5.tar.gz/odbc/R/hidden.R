#' Internal page for hidden aliases
#'
#' For S4 methods that require a documentation entry but only clutter the index.
#'
#' @usage NULL
#' @format NULL
#' @keywords internal
hidden_aliases <- NULL
