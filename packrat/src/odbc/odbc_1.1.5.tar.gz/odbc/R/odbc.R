#' @aliases NULL
#' @importFrom Rcpp sourceCpp
#' @importFrom blob blob
#' @importFrom bit64 integer64
#' @importFrom hms hms
#' @useDynLib odbc, .registration = TRUE
"_PACKAGE"
